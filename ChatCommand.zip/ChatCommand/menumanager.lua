if Announcer then
	Announcer:AddHostMod('Chat Command, (Say [!help] for more info about this lobby)')
end